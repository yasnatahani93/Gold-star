
const userText = document.getElementById("userText");
const responseText = document.getElementById("responseText");

function startVoice() {
  const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
  recognition.lang = 'fa-IR';

  recognition.onresult = function (event) {
    const text = event.results[0][0].transcript;
    userText.textContent = "🔊 گفتی: " + text;

    const answer = `سلام! من گولد استار هستم 🤖. سوالت این بود: "${text}" — خیلی جالبه!`;
    responseText.textContent = "🤖 جواب: " + answer;

    const utterance = new SpeechSynthesisUtterance(answer);
    utterance.lang = 'fa-IR';
    speechSynthesis.speak(utterance);
  };

  recognition.onerror = function () {
    userText.textContent = "❌ خطا در ضبط صدا";
  };

  recognition.start();
}
